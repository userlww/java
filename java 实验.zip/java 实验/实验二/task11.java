import java.util.Scanner;
public class task11{
	public static void main(String[] args){
		
	}
}