import java.util.Scanner;
import java.math.*;
class aa
{
	int x,y,c;
	int Gong;
	aa(int a,int b)
	{
		x=a;
		y=b;
		c=x%y;
	}
	int run1()
	{
		while(c!=0)
		{
			x=y;
			x=c;
			c=x%y;	
		}
		return y;
	}
	int run2()
	{
		if(c==0)
		{
			return y;
		}
		else {
			return new aa(y,x%y).run2();
		}
	}
}
public class text1 {
	public static void main(String ards[])
	{
		System.out.println("��������������");
		int a,b;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		aa c=new aa(Math.max(a, b),Math.min(a, b));
		System.out.println("�÷ǵݹ鷨��õ����Լ��Ϊ"+c.run1());
		System.out.println("�õݹ鷨��õ����Լ��Ϊ"+c.run2());
	}

}
