import java.util.Scanner;
class Complex{
	int realPart,maginPart;
	Complex()
	{
		realPart=0;
		maginPart=0;
	}
	Complex(int a,int b){
		realPart=a;
	    maginPart=b;
	}
	Complex complexadd(Complex a)
	{
	  Complex sum=new Complex();
	  sum.realPart=this.realPart+a.realPart;
	  sum.maginPart=this.maginPart+a.maginPart;
	  return sum;
	}
	String tostring() {
		return realPart+"+"+maginPart+"i";
	}
}
public class text2 {
	public static void main(String[] args) {
		int a, b;
		System.out.println("�����븴��1��ʵ�����鲿");
		Scanner sc=new Scanner(System.in);
	    a=sc.nextInt();
	    b=sc.nextInt();
	    Complex num1=new Complex(a,b);
	   System.out.println("��һ������Ϊ"+num1.tostring());
	   int c=sc.nextInt();
	   int d=sc.nextInt();
	    Complex num2=new Complex(c,d);
	    System.out.println("�ڶ�������Ϊ"+num2.tostring());
	    System.out.println("��͵Ľ��Ϊ"+num1.complexadd(num2).tostring());
	}
}
