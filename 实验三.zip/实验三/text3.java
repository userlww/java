import java.util.Scanner;
class round
{
	double x,y,r;
	round()
	{
		x=0;
		y=0;
		r=0;
	}
	round(double a,double b,double c){
		x=a;
		y=b;
		r=c;
	}
	double zc()
	{
		return Math.PI*2*r;
	}
	double mj()
	{
		return Math.PI*r*r;
	}
}
public class text3 {
	public static void main(String[] args)
	{
		System.out .println("������Բ�ĳ�ʼ������");
	Scanner sc=new Scanner(System.in);
	double a=sc.nextDouble();
	double b=sc.nextDouble();
	double r=sc.nextDouble();
	round yuan1=new round(a,b,r);
	System.out.println("Բ���ܳ�Ϊ"+yuan1.zc());
	System.out.println("Բ�����Ϊ"+yuan1.mj());
	}
 
}
