import java.util.Scanner;
class Person
{
	String number;
	String name;
	String sex;
	Person(String a,String b,String c){
		number=a;
		name=b;
		sex=c;
	}
   void  setName(String a)
   {
	   name=a;
   }
   void setNumber(String a)
   {
	   number=a;
   }
   String getNumber() {
	   return number;
	   
   }
   String getName()
   {
	   return name;
	   }
}
class Teacher extends Person{
	String department;
	Teacher(String a,String b,String c,String d)
	{
		super(a,b,c);
		department=d;
}
	String getDepart()
	{
		return department;
	}
	
}
class Student extends Person{
	String classNum;
	 Student(String a,String b,String c,String d)
 { 
		super(a,b,c);
	    classNum=d;	
 }
	 void setClass(String a)
	 {
		 classNum=a;
	 }
	 }
class classes{
	String classname;
	Student nameList[]=new Student[100];
	classes(String a) {
        classname=a;
	}
	int creatNameList() {
		System.out.println("������༶��");
		int i;
		String number;
		String name,sex;
		Scanner sc=new Scanner(System.in);
		i=sc.nextInt();
		System.out.println("������ð༶ѧ����ѧ�ţ��������Ա�");
		for(int j=0;j<i;j++) {
			number=sc.next();
			name=sc.next();
			sex=sc.next();
			nameList[j]=new Student(number,name,sex,classname);
		}
		return i;
	}
	void output(int i)
	{   
	    System.out.printf("ѧ��\t");
		System.out.printf("����\t");
		System.out.printf("�༶����\t");
		System.out.println();
		for(int k=0;k<i;k++)
		{
			System.out.printf(nameList[k].getNumber()+"\t");
			System.out.printf(nameList[k].getName()+"\t");
			System.out.printf(nameList[k].classNum+"\t");
			System.out.println();
		}
	}
}
public class text5 {
  public static void main(String[] args)
  {
	  Scanner sc1=new Scanner(System.in);
	  System.out.println("������༶����");
	  String demo;
	  demo=sc1.next();
	  classes   classone=new classes(demo);
	  classone.output(classone.creatNameList());
  }
}
